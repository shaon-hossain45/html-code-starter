import ImageViewer from './ImageViewer';
import FullScreenViewer from './FullScreen';

ImageViewer.FullScreenViewer = FullScreenViewer;

export default ImageViewer;
