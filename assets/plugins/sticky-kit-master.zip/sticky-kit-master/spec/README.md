# sticky kit spec suite

How to run

```bash
npm install
tup init
tup upd
```

Open `spec/index.html` in your browser.
