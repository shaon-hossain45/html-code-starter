# jquery-oddMenOut

A jQuery plugin that highlights cells in a table that are different from the most commonly found value.

